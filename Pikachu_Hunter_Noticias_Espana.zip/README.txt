PIKACHU HUNTER — NOTICIAS Y AVISOS DE PIKACHU

Esta versión conserva el álbum y añade un panel de noticias de Pikachu. Un flujo de GitHub Actions revisa cada día la página pública de noticias oficial de Pokémon GO, busca artículos que mencionen Pikachu, guarda los enlaces y manda una notificación cuando detecta un artículo nuevo.

IMPORTANTE
- El detector revisa anuncios publicados en la web oficial; no puede leer la cuenta del jugador ni detectar Pikachu salvajes o incursiones en directo.
- No existe una API pública oficial de Pokémon GO que permita detectar todos los encuentros del juego.
- La región, los horarios, el método de aparición, Shiny y fondos especiales deben confirmarse en el anuncio enlazado. El panel no inventa esos datos.
- Solo se muestran artículos que mencionan Pikachu; no se monitorizan otros Pokémon.

PARA ACTIVAR LOS AVISOS EN EL REDMI
1. Sube todos los archivos de esta carpeta a tu repositorio de GitHub, manteniendo las carpetas .github y scripts.
2. En GitHub, entra en Settings > Secrets and variables > Actions > New repository secret.
3. Nombre del secreto: NTFY_TOPIC
4. Valor: el nombre exacto del tema al que está suscrito tu móvil en ntfy.
5. Guarda el secreto.
6. En GitHub, abre Actions y ejecuta una vez “Revisar noticias oficiales de Pikachu” con Run workflow.
7. La revisión automática se ejecutará cada día. Abre tu Pikachu Hunter publicado en HTTPS y entra en Noticias.

PARA VERLO EN ANDROID
Abre la dirección HTTPS de Pikachu Hunter en Chrome. Si ya está instalada, ciérrala y vuelve a abrirla para cargar la versión nueva. El álbum conserva el guardado local siempre que mantengas el mismo navegador y no borres sus datos.

FUENTE PRINCIPAL
https://pokemongolive.com/news/?hl=es

Proyecto fan no oficial. Pokémon GO y Pokémon pertenecen a sus respectivos titulares.
