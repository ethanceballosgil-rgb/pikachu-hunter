PIKACHU HUNTER — VERSIÓN MEJORADA

Incluye catálogo de 103 disfraces de Pikachu + Pikachu normal, Dinamax, Gigamax y variocolor; checklist, filtro/buscador, progreso y guardado local en el navegador. También incluye enlaces de búsqueda de parques y gimnasios en Google Maps.

IMPORTANTE: No detecta apariciones ni incursiones en directo, no accede a Pokémon GO y no puede confirmar ubicaciones de Pikachu. Los enlaces de mapas son búsquedas generales, no avistamientos. La lista es una referencia de catálogo a fecha de noviembre de 2026 y puede necesitar actualizaciones; no todas las formas están disponibles en todos los eventos.

USO EN REDMI:
1. Descomprime este ZIP.
2. Para probar, abre index.html en Chrome (algunas funciones PWA requieren HTTPS).
3. Para instalar como app: publica la carpeta en un alojamiento HTTPS y abre la web con Chrome; menú ⋮ > Instalar aplicación o Añadir a pantalla de inicio.
4. Las marcas se guardan en el almacenamiento local de ese navegador/móvil. Si borras los datos del navegador, podrías perderlas.

Fuentes de referencia:
https://www.dittobase.com/pokemon-go/pokedex/pikachu
https://bulbapedia.bulbagarden.net/wiki/Pikachu_(GO)
Proyecto fan no oficial. No afiliado a Pokémon GO ni a sus titulares.

Actualización: catálogo presentado como álbum de pegatinas con tarjetas numeradas, casillas, filtros y progreso.

COMPROBADOR CADA 2 HORAS Y NOTIFICACIONES
-----------------------------------------
Se ha añadido .github/workflows/buscar-pikachu.yml y scripts/check_pikachu.py.

IMPORTANTE: Pokémon GO no ofrece una API pública oficial para consultar los Pokémon
salvajes que aparecen en la cuenta o cerca de una persona. Este comprobador NO puede
averiguar apariciones por sí solo: necesita una fuente pública/permitida que entregue
un JSON de apariciones. No introduzcas tu contraseña ni uses bots que entren en tu cuenta.

Formato que debe devolver la fuente configurada en PIKACHU_FEED_URL:
[
  {"id":"id-unico", "name":"Pikachu", "costume":"Disfraz", "wild":true,
   "source_url":"https://ejemplo.com/ficha"}
]

CONFIGURACIÓN EN GITHUB (una sola vez):
1. Sube esta carpeta al repositorio, manteniendo la ruta .github/workflows/.
2. En GitHub abre Settings > Secrets and variables > Actions > New repository secret.
3. Crea PIKACHU_FEED_URL con la URL de una fuente pública fiable que entregue el JSON
   del formato anterior. Sin esa fuente no habrá detección automática real.
4. Instala la app ntfy en el Redmi y suscríbete a un tema privado con un nombre difícil
   de adivinar. En GitHub crea el secreto NTFY_TOPIC con exactamente ese nombre.
5. En Actions activa los workflows si GitHub te lo pide.

GitHub Actions ejecutará la comprobación aproximadamente cada 2 horas (los horarios
programados pueden retrasarse). También se puede probar manualmente desde Actions >
Buscar Pikachu disfrazados salvajes > Run workflow.
